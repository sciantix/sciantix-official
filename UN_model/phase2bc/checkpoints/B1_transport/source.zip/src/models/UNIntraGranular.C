#include "UNIntraGranular.h"
#include "Solver.h"

#include <cmath>
#include <stdexcept>
#include <vector>

namespace un_l3
{
void advanceExchange(Solver& solver, State& state, const ExchangeCoefficients& c, double dt)
{
    const double inputs[] = {dt, c.diffusivity, c.grain_radius, c.source_c,
                             c.trapping_bulk, c.trapping_dislocation,
                             c.resolution_bulk, c.resolution_dislocation, c.source_mb, c.source_md};
    for (double value : inputs)
        if (!std::isfinite(value))
            throw std::invalid_argument("Non-finite UN exchange input");
    if (dt < 0.0 || c.diffusivity < 0.0 || c.grain_radius <= 0.0 ||
        c.trapping_bulk < 0.0 || c.trapping_dislocation < 0.0 ||
        c.resolution_bulk < 0.0 || c.resolution_dislocation < 0.0)
        throw std::invalid_argument("Invalid UN exchange coefficient or timestep");
    for (const auto& population : state.modes)
    {
        if (population.size() != state.numberOfModes())
            throw std::invalid_argument("UN spectral vector size does not match state mode count");
        for (double value : population)
            if (!std::isfinite(value))
                throw std::invalid_argument("Non-finite UN spectral coefficient");
    }

    const std::vector<double> parameters = {
        static_cast<double>(state.numberOfModes()), c.diffusivity, c.grain_radius, c.source_c,
        c.trapping_bulk, c.trapping_dislocation, c.resolution_bulk, c.resolution_dislocation,
        c.source_mb, c.source_md};
    solver.SpectralDiffusion3equationsExchange(
        state.averages[0], state.averages[1], state.averages[2],
        state.modes[0].data(), state.modes[1].data(), state.modes[2].data(), parameters, dt);

    for (double value : state.averages)
        if (!std::isfinite(value))
            throw std::runtime_error("Non-finite UN exchange result");
    for (const auto& population : state.modes)
        for (double value : population)
            if (!std::isfinite(value))
                throw std::runtime_error("Non-finite UN exchange mode result");
}
}  // namespace un_l3
