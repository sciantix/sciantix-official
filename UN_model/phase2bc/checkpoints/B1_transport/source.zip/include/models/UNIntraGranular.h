#ifndef SCIANTIX_UN_L3_INTRAGRANULAR_H
#define SCIANTIX_UN_L3_INTRAGRANULAR_H

#include "UNParameters.h"
#include "UNState.h"

class Solver;

namespace un_l3
{
// Numerical exchange only: mutates modes and averages, preserving every other
// state field. dt is in seconds and can be zero. No time/production/GF update.
void advanceExchange(Solver& solver, State& state, const ExchangeCoefficients& coefficients, double dt);
}

#endif
