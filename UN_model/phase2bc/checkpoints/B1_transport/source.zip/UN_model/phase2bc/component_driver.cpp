#include "UNTransport.h"
#include "UNIntraGranular.h"
#include "Solver.h"
#include "parameter_loader.h"
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <vector>

int main(int argc, char** argv)
{
    try {
        if (argc != 5) throw std::runtime_error("component_driver component parameters input output");
        un_l3::Parameters p;
        loadParameters(argv[2],p);
        un_l3::PhysicsOptions o;
        std::ifstream input(argv[3]);
        std::ofstream output(argv[4],std::ios::binary);
        const std::string component=argv[1];
        std::size_t rows; input>>rows;
        if (!input || !output) throw std::runtime_error("Cannot open component fixture");
        for (std::size_t i=0;i<rows;++i) {
            std::vector<double> result;
            if (component=="transport") {
                double rb,nb,rd,nd,c; input>>rb>>nb>>rd>>nd>>c;
                auto dg=un_l3::xeDiffusivity(p), dv=un_l3::vacancyDiffusivity(p);
                auto b=un_l3::resolutionRates(p,rb,rd);
                auto g=un_l3::trappingRates(p,o,dg.total,rb,nb,rd,nd);
                result={dg.total,dg.first,dg.second,dg.third,dv.total,dv.first,dv.second,dv.dislocation,
                        b.first,b.second,g.bulk,g.dislocation,g.gamma,g.denominator,g.free_line,g.bubble_term,g.line_term,
                        un_l3::productionRate(p),un_l3::nucleationRate(p,dg.total,c),un_l3::grainBoundaryDiffusivity(p,o,dv.first)};
            }
            else throw std::runtime_error("Unknown component");
            if (!input) throw std::runtime_error("Incomplete component fixture row");
            output.write(reinterpret_cast<const char*>(result.data()),result.size()*sizeof(double));
        }
        if (!output) throw std::runtime_error("Cannot write component output");
        return 0;
    } catch(const std::exception& e) { std::cerr<<e.what()<<"\n"; return 1; }
}
